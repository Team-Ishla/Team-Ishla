from flask import Flask,render_template,request
app = Flask(__name__)

#@app.route('/',methods=['GET','POST'])
#def index():
#    if request.method=='POST':
#        print (request.form.getlist('Category'))
#        return("Done")
#   return render_template('home.html')
@app.route('/')
def default():
   return render_template('home.html')

@app.route('/Calculate Route',methods=['GET','POST'])
def home():
    if request.method=='POST':
      data2=request.form.getlist('Category')
      data1=request.form['address']

    return render_template('result.html',value1=data1,value2=data2)

if __name__ == "__main__":
    app.run(debug=True)
